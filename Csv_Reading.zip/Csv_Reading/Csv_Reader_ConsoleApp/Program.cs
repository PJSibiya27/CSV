﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Csv_Reader_Lib;

namespace Csv_Reader_ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            var contactList = ReadCsv();

            string path2 = @"C:\Filepath1.txt";
            StreamWriter sw = new StreamWriter(path2);
            sw.WriteLine("LastName Frequencies...");
            //
            // LastName frequencies
            //
            var frequencies = GetLastNameFrequencies(contactList);

            var sortedFrequencies = frequencies.OrderByDescending(f => f.Counter)
                                               .ThenBy(f => f.Name);
            
            foreach (var freq in sortedFrequencies)
            {
                sw.WriteLine("{0}, {1}", freq.Name.ToString(), freq.Counter);
            }
            
            sw.WriteLine("List of names...");
            //
            // List of names
            //
            var names = GetListOfNames(contactList);

            var distinctNames = names.Select(n => n).Distinct();

            foreach (var name in distinctNames)
            {
                
                sw.WriteLine("{0}", name);
            }

            sw.WriteLine("List of FirstName Frequencies...");
            //
            // FirstName frequencies
            //
            var firstNameFrequencies = GetFirstNameFrequencies(contactList);

            var sortedFirstNameFrequencies = firstNameFrequencies.OrderByDescending(f => f.Counter)
                                               .ThenBy(f => f.Name);
            
            foreach (var freq in sortedFirstNameFrequencies)
            {
                
                sw.WriteLine("{0}, {1}", freq.Name.ToString(), freq.Counter);
            }
            sw.Close();
          
            //
            // List of addresses
            //
            string path3 = @"C:\Filepath2.txt";
            StreamWriter SSW = new StreamWriter(path3);
            SSW.WriteLine("List of Addresses...");
            var addressList = GetAddresses(contactList);

            var sortedAddresses = addressList.OrderBy(a => a.Split(' ')[1]).ToList();

            
            foreach (var add in sortedAddresses)
            {
                SSW.WriteLine("{0}", add);
            }

            SSW.Close();
        }

        public static List<Contact> ReadCsv()
        {
            using (var reader = new StreamReader(@"C:\data.csv"))
            {
                var contactsList = new List<Contact>();
                while (!reader.EndOfStream)
                {

                    var line = reader.ReadLine();

                    // skip first row (csv headers)
                    if (line.Contains("FirstName,LastName,Address,PhoneNumber"))
                        continue;

                    var contactDetails = line.Split(',');

                    contactsList.Add(new Contact
                    {
                        FirstName = contactDetails[0],
                        LastName = contactDetails[1],
                        Address = contactDetails[2],
                        PhoneNumber = contactDetails[3]
                    });
                }

                return contactsList;
            }
        }
        
        public static List<Frequency> GetLastNameFrequencies(List<Contact> list)
        {
            var frequencies = new List<Frequency>();
            var lastNames = list.Select(x => x.LastName).ToList();
            var distinctLastNames = lastNames.Select(n => n).Distinct().ToList();

            foreach (var lastName in distinctLastNames)
            {
                var frequencyItem = new Frequency();
                var counter = lastNames.Count(n => n == lastName);
                
                frequencyItem.Name = lastName;
                frequencyItem.Counter = counter;
                frequencies.Add(frequencyItem);
                
            }

            return frequencies;
        }

        public static List<string> GetAddresses(List<Contact> list)
        {
            return list.Select(c => c.Address).ToList();
        }

        public static List<string> GetListOfNames(List<Contact> list)
        {
            return list.Select(n => n.FirstName + " " + n.LastName).ToList();
        }

        public static List<Frequency> GetFirstNameFrequencies(List<Contact> list)
        {
            var frequencies = new List<Frequency>();
            var firstNames = list.Select(x => x.FirstName).ToList();
            var distinctFirstNames = firstNames.Select(n => n).Distinct();

            foreach (var firstName in distinctFirstNames)
            {
                var frequencyItem = new Frequency();
                var counter = firstNames.Count(n => n == firstName);

                frequencyItem.Name = firstName;
                frequencyItem.Counter = counter;
                frequencies.Add(frequencyItem);

            }

            return frequencies;
        }
    }
}
